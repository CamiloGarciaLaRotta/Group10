README
=========
The following is a breakdown of the files that have been submitted:
	Report.pdf: 
		Discusses the entire release pipeline, and includes a copy of the updated work plan.
	CurrentTestingState.pdf:
		Gives an overview of the testing practices that have been carried out, and gives
		results leading to an understanding of how reliably the system performs.
