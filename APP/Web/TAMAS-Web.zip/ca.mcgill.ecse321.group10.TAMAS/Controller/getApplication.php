<?php
// REQUIRE WHAT FOR APPLICATION?


$id = $_POST['id'];

echo $cc->getBudget($id);
?>