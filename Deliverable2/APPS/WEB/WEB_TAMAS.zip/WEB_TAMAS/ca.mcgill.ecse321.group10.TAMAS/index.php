<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="UTF-8">
		<title> TAMAS </title>
		<style>
			.error {color: #FF0000;}
		</style>
	</head>
	<body>
		<!-- TO HELL WITH YOUR UNREALISTIC WEB BEAUTY STANDARDS -->
		<center><br>
		<form action="./View/createCourse.php">
		    <input type="submit" value="Create Course" />
		</form><br>
		<form action="./View/createInstructor.php">
		    <input type="submit" value="Create Instructor" />
		</form><br>
		<form action="./View/job.php">
		    <input type="submit" value="Manage Job Postings" />
		</form><br>
		</center>
	</body>
</html>