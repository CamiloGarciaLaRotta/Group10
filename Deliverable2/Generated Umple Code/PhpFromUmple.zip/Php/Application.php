<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

class Application
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static $nextId = 1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Application Attributes
  private $postingID;

  //Autounique Attributes
  private $id;

  //Application Associations
  private $student;
  private $instructors;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aPostingID)
  {
    $this->postingID = $aPostingID;
    $this->id = self::$nextId++;
    $this->student = array();
    $this->instructors = array();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setPostingID($aPostingID)
  {
    $wasSet = false;
    $this->postingID = $aPostingID;
    $wasSet = true;
    return $wasSet;
  }

  public function getPostingID()
  {
    return $this->postingID;
  }

  public function getId()
  {
    return $this->id;
  }

  public function getStudent_index($index)
  {
    $aStudent = $this->student[$index];
    return $aStudent;
  }

  public function getStudent()
  {
    $newStudent = $this->student;
    return $newStudent;
  }

  public function numberOfStudent()
  {
    $number = count($this->student);
    return $number;
  }

  public function hasStudent()
  {
    $has = $this->numberOfStudent() > 0;
    return $has;
  }

  public function indexOfStudent($aStudent)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->student as $student)
    {
      if ($student->equals($aStudent))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getInstructor_index($index)
  {
    $aInstructor = $this->instructors[$index];
    return $aInstructor;
  }

  public function getInstructors()
  {
    $newInstructors = $this->instructors;
    return $newInstructors;
  }

  public function numberOfInstructors()
  {
    $number = count($this->instructors);
    return $number;
  }

  public function hasInstructors()
  {
    $has = $this->numberOfInstructors() > 0;
    return $has;
  }

  public function indexOfInstructor($aInstructor)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->instructors as $instructor)
    {
      if ($instructor->equals($aInstructor))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfStudent()
  {
    return 0;
  }

  public function addStudent($aStudent)
  {
    $wasAdded = false;
    if ($this->indexOfStudent($aStudent) !== -1) { return false; }
    $this->student[] = $aStudent;
    if ($aStudent->indexOfApplication($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aStudent->addApplication($this);
      if (!$wasAdded)
      {
        array_pop($this->student);
      }
    }
    return $wasAdded;
  }

  public function removeStudent($aStudent)
  {
    $wasRemoved = false;
    if ($this->indexOfStudent($aStudent) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfStudent($aStudent);
    unset($this->student[$oldIndex]);
    if ($aStudent->indexOfApplication($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aStudent->removeApplication($this);
      if (!$wasRemoved)
      {
        $this->student[$oldIndex] = $aStudent;
        ksort($this->student);
      }
    }
    $this->student = array_values($this->student);
    return $wasRemoved;
  }

  public function addStudentAt($aStudent, $index)
  {  
    $wasAdded = false;
    if($this->addStudent($aStudent))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfStudent()) { $index = $this->numberOfStudent() - 1; }
      array_splice($this->student, $this->indexOfStudent($aStudent), 1);
      array_splice($this->student, $index, 0, array($aStudent));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveStudentAt($aStudent, $index)
  {
    $wasAdded = false;
    if($this->indexOfStudent($aStudent) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfStudent()) { $index = $this->numberOfStudent() - 1; }
      array_splice($this->student, $this->indexOfStudent($aStudent), 1);
      array_splice($this->student, $index, 0, array($aStudent));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addStudentAt($aStudent, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfInstructors()
  {
    return 0;
  }

  public function addInstructor($aInstructor)
  {
    $wasAdded = false;
    if ($this->indexOfInstructor($aInstructor) !== -1) { return false; }
    $this->instructors[] = $aInstructor;
    if ($aInstructor->indexOfApplication($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aInstructor->addApplication($this);
      if (!$wasAdded)
      {
        array_pop($this->instructors);
      }
    }
    return $wasAdded;
  }

  public function removeInstructor($aInstructor)
  {
    $wasRemoved = false;
    if ($this->indexOfInstructor($aInstructor) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfInstructor($aInstructor);
    unset($this->instructors[$oldIndex]);
    if ($aInstructor->indexOfApplication($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aInstructor->removeApplication($this);
      if (!$wasRemoved)
      {
        $this->instructors[$oldIndex] = $aInstructor;
        ksort($this->instructors);
      }
    }
    $this->instructors = array_values($this->instructors);
    return $wasRemoved;
  }

  public function addInstructorAt($aInstructor, $index)
  {  
    $wasAdded = false;
    if($this->addInstructor($aInstructor))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfInstructors()) { $index = $this->numberOfInstructors() - 1; }
      array_splice($this->instructors, $this->indexOfInstructor($aInstructor), 1);
      array_splice($this->instructors, $index, 0, array($aInstructor));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveInstructorAt($aInstructor, $index)
  {
    $wasAdded = false;
    if($this->indexOfInstructor($aInstructor) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfInstructors()) { $index = $this->numberOfInstructors() - 1; }
      array_splice($this->instructors, $this->indexOfInstructor($aInstructor), 1);
      array_splice($this->instructors, $index, 0, array($aInstructor));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addInstructorAt($aInstructor, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $copyOfStudent = $this->student;
    $this->student = array();
    foreach ($copyOfStudent as $aStudent)
    {
      $aStudent->removeApplication($this);
    }
    $copyOfInstructors = $this->instructors;
    $this->instructors = array();
    foreach ($copyOfInstructors as $aInstructor)
    {
      $aInstructor->removeApplication($this);
    }
  }

}
?>