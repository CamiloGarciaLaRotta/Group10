<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

class ProfileManager
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static $theInstance = null;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ProfileManager Associations
  private $userProfiles;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private function __construct()
  {
    $this->userProfiles = array();
  }

  public static function getInstance()
  {
    if(self::$theInstance == null)
    {
      self::$theInstance = new ProfileManager();
    }
    return self::$theInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function getUserProfile_index($index)
  {
    $aUserProfile = $this->userProfiles[$index];
    return $aUserProfile;
  }

  public function getUserProfiles()
  {
    $newUserProfiles = $this->userProfiles;
    return $newUserProfiles;
  }

  public function numberOfUserProfiles()
  {
    $number = count($this->userProfiles);
    return $number;
  }

  public function hasUserProfiles()
  {
    $has = $this->numberOfUserProfiles() > 0;
    return $has;
  }

  public function indexOfUserProfile($aUserProfile)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->userProfiles as $userProfile)
    {
      if ($userProfile->equals($aUserProfile))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfUserProfiles()
  {
    return 0;
  }

  public function addUserProfileVia($aId, $aUsername, $aPassword, $aFirstName, $aLastName)
  {
    return new Profile($aId, $aUsername, $aPassword, $aFirstName, $aLastName, $this);
  }

  public function addUserProfile($aUserProfile)
  {
    $wasAdded = false;
    if ($this->indexOfUserProfile($aUserProfile) !== -1) { return false; }
    $existingProfileManager = $aUserProfile->getProfileManager();
    $isNewProfileManager = $existingProfileManager != null && $this !== $existingProfileManager;
    if ($isNewProfileManager)
    {
      $aUserProfile->setProfileManager($this);
    }
    else
    {
      $this->userProfiles[] = $aUserProfile;
    }
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeUserProfile($aUserProfile)
  {
    $wasRemoved = false;
    //Unable to remove aUserProfile, as it must always have a profileManager
    if ($this !== $aUserProfile->getProfileManager())
    {
      unset($this->userProfiles[$this->indexOfUserProfile($aUserProfile)]);
      $this->userProfiles = array_values($this->userProfiles);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addUserProfileAt($aUserProfile, $index)
  {  
    $wasAdded = false;
    if($this->addUserProfile($aUserProfile))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfUserProfiles()) { $index = $this->numberOfUserProfiles() - 1; }
      array_splice($this->userProfiles, $this->indexOfUserProfile($aUserProfile), 1);
      array_splice($this->userProfiles, $index, 0, array($aUserProfile));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveUserProfileAt($aUserProfile, $index)
  {
    $wasAdded = false;
    if($this->indexOfUserProfile($aUserProfile) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfUserProfiles()) { $index = $this->numberOfUserProfiles() - 1; }
      array_splice($this->userProfiles, $this->indexOfUserProfile($aUserProfile), 1);
      array_splice($this->userProfiles, $index, 0, array($aUserProfile));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addUserProfileAt($aUserProfile, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    while (count($this->userProfiles) > 0)
    {
      $aUserProfile = $this->userProfiles[count($this->userProfiles) - 1];
      $aUserProfile->delete();
      unset($this->userProfiles[$this->indexOfUserProfile($aUserProfile)]);
      $this->userProfiles = array_values($this->userProfiles);
    }
    
  }

}
?>