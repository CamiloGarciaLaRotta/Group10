<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

class Course
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Course Attributes
  private $className;
  private $cdn;

  /**
   * time budget
   */
  private $graderTimeBudget;

  /**
   * time budget
   */
  private $taTimeBudget;

  //Course Associations
  private $timeslots;
  private $jobs;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aClassName, $aCdn, $aGraderTimeBudget, $aTaTimeBudget)
  {
    $this->className = $aClassName;
    $this->cdn = $aCdn;
    $this->graderTimeBudget = $aGraderTimeBudget;
    $this->taTimeBudget = $aTaTimeBudget;
    $this->timeslots = array();
    $this->jobs = array();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setClassName($aClassName)
  {
    $wasSet = false;
    $this->className = $aClassName;
    $wasSet = true;
    return $wasSet;
  }

  public function setGraderTimeBudget($aGraderTimeBudget)
  {
    $wasSet = false;
    $this->graderTimeBudget = $aGraderTimeBudget;
    $wasSet = true;
    return $wasSet;
  }

  public function setTaTimeBudget($aTaTimeBudget)
  {
    $wasSet = false;
    $this->taTimeBudget = $aTaTimeBudget;
    $wasSet = true;
    return $wasSet;
  }

  public function getClassName()
  {
    return $this->className;
  }

  public function getCdn()
  {
    return $this->cdn;
  }

  public function getGraderTimeBudget()
  {
    return $this->graderTimeBudget;
  }

  public function getTaTimeBudget()
  {
    return $this->taTimeBudget;
  }

  public function getTimeslot_index($index)
  {
    $aTimeslot = $this->timeslots[$index];
    return $aTimeslot;
  }

  public function getTimeslots()
  {
    $newTimeslots = $this->timeslots;
    return $newTimeslots;
  }

  public function numberOfTimeslots()
  {
    $number = count($this->timeslots);
    return $number;
  }

  public function hasTimeslots()
  {
    $has = $this->numberOfTimeslots() > 0;
    return $has;
  }

  public function indexOfTimeslot($aTimeslot)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->timeslots as $timeslot)
    {
      if ($timeslot->equals($aTimeslot))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getJob_index($index)
  {
    $aJob = $this->jobs[$index];
    return $aJob;
  }

  public function getJobs()
  {
    $newJobs = $this->jobs;
    return $newJobs;
  }

  public function numberOfJobs()
  {
    $number = count($this->jobs);
    return $number;
  }

  public function hasJobs()
  {
    $has = $this->numberOfJobs() > 0;
    return $has;
  }

  public function indexOfJob($aJob)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->jobs as $job)
    {
      if ($job->equals($aJob))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfTimeslots()
  {
    return 0;
  }

  public function addTimeslotVia($aStartTime, $aEndTime)
  {
    return new TimeSlot($aStartTime, $aEndTime, $this);
  }

  public function addTimeslot($aTimeslot)
  {
    $wasAdded = false;
    if ($this->indexOfTimeslot($aTimeslot) !== -1) { return false; }
    $existingCourse = $aTimeslot->getCourse();
    $isNewCourse = $existingCourse != null && $this !== $existingCourse;
    if ($isNewCourse)
    {
      $aTimeslot->setCourse($this);
    }
    else
    {
      $this->timeslots[] = $aTimeslot;
    }
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeTimeslot($aTimeslot)
  {
    $wasRemoved = false;
    //Unable to remove aTimeslot, as it must always have a course
    if ($this !== $aTimeslot->getCourse())
    {
      unset($this->timeslots[$this->indexOfTimeslot($aTimeslot)]);
      $this->timeslots = array_values($this->timeslots);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addTimeslotAt($aTimeslot, $index)
  {  
    $wasAdded = false;
    if($this->addTimeslot($aTimeslot))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTimeslots()) { $index = $this->numberOfTimeslots() - 1; }
      array_splice($this->timeslots, $this->indexOfTimeslot($aTimeslot), 1);
      array_splice($this->timeslots, $index, 0, array($aTimeslot));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveTimeslotAt($aTimeslot, $index)
  {
    $wasAdded = false;
    if($this->indexOfTimeslot($aTimeslot) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTimeslots()) { $index = $this->numberOfTimeslots() - 1; }
      array_splice($this->timeslots, $this->indexOfTimeslot($aTimeslot), 1);
      array_splice($this->timeslots, $index, 0, array($aTimeslot));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addTimeslotAt($aTimeslot, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfJobs()
  {
    return 0;
  }

  public function addJob($aJob)
  {
    $wasAdded = false;
    if ($this->indexOfJob($aJob) !== -1) { return false; }
    $this->jobs[] = $aJob;
    if ($aJob->indexOfCourse($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aJob->addCourse($this);
      if (!$wasAdded)
      {
        array_pop($this->jobs);
      }
    }
    return $wasAdded;
  }

  public function removeJob($aJob)
  {
    $wasRemoved = false;
    if ($this->indexOfJob($aJob) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfJob($aJob);
    unset($this->jobs[$oldIndex]);
    if ($aJob->indexOfCourse($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aJob->removeCourse($this);
      if (!$wasRemoved)
      {
        $this->jobs[$oldIndex] = $aJob;
        ksort($this->jobs);
      }
    }
    $this->jobs = array_values($this->jobs);
    return $wasRemoved;
  }

  public function addJobAt($aJob, $index)
  {  
    $wasAdded = false;
    if($this->addJob($aJob))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfJobs()) { $index = $this->numberOfJobs() - 1; }
      array_splice($this->jobs, $this->indexOfJob($aJob), 1);
      array_splice($this->jobs, $index, 0, array($aJob));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveJobAt($aJob, $index)
  {
    $wasAdded = false;
    if($this->indexOfJob($aJob) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfJobs()) { $index = $this->numberOfJobs() - 1; }
      array_splice($this->jobs, $this->indexOfJob($aJob), 1);
      array_splice($this->jobs, $index, 0, array($aJob));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addJobAt($aJob, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    while (count($this->timeslots) > 0)
    {
      $aTimeslot = $this->timeslots[count($this->timeslots) - 1];
      $aTimeslot->delete();
      unset($this->timeslots[$this->indexOfTimeslot($aTimeslot)]);
      $this->timeslots = array_values($this->timeslots);
    }
    
    while (count($this->jobs) > 0)
    {
      $aJob = $this->jobs[count($this->jobs) - 1];
      $aJob->delete();
      unset($this->jobs[$this->indexOfJob($aJob)]);
      $this->jobs = array_values($this->jobs);
    }
    
  }

}
?>