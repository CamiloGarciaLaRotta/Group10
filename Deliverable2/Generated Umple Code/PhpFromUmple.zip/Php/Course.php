<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

class Course
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Course Attributes
  private $className;
  private $cdn;

  /**
   * time budget
   */
  private $graderTimeBudget;

  /**
   * time budget
   */
  private $taTimeBudget;

  //Course Associations
  private $tutorials;
  private $laboratories;
  private $jobs;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aClassName, $aCdn, $aGraderTimeBudget, $aTaTimeBudget)
  {
    $this->className = $aClassName;
    $this->cdn = $aCdn;
    $this->graderTimeBudget = $aGraderTimeBudget;
    $this->taTimeBudget = $aTaTimeBudget;
    $this->tutorials = array();
    $this->laboratories = array();
    $this->jobs = array();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setClassName($aClassName)
  {
    $wasSet = false;
    $this->className = $aClassName;
    $wasSet = true;
    return $wasSet;
  }

  public function setGraderTimeBudget($aGraderTimeBudget)
  {
    $wasSet = false;
    $this->graderTimeBudget = $aGraderTimeBudget;
    $wasSet = true;
    return $wasSet;
  }

  public function setTaTimeBudget($aTaTimeBudget)
  {
    $wasSet = false;
    $this->taTimeBudget = $aTaTimeBudget;
    $wasSet = true;
    return $wasSet;
  }

  public function getClassName()
  {
    return $this->className;
  }

  public function getCdn()
  {
    return $this->cdn;
  }

  public function getGraderTimeBudget()
  {
    return $this->graderTimeBudget;
  }

  public function getTaTimeBudget()
  {
    return $this->taTimeBudget;
  }

  public function getTutorial_index($index)
  {
    $aTutorial = $this->tutorials[$index];
    return $aTutorial;
  }

  public function getTutorials()
  {
    $newTutorials = $this->tutorials;
    return $newTutorials;
  }

  public function numberOfTutorials()
  {
    $number = count($this->tutorials);
    return $number;
  }

  public function hasTutorials()
  {
    $has = $this->numberOfTutorials() > 0;
    return $has;
  }

  public function indexOfTutorial($aTutorial)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->tutorials as $tutorial)
    {
      if ($tutorial->equals($aTutorial))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getLaboratory_index($index)
  {
    $aLaboratory = $this->laboratories[$index];
    return $aLaboratory;
  }

  public function getLaboratories()
  {
    $newLaboratories = $this->laboratories;
    return $newLaboratories;
  }

  public function numberOfLaboratories()
  {
    $number = count($this->laboratories);
    return $number;
  }

  public function hasLaboratories()
  {
    $has = $this->numberOfLaboratories() > 0;
    return $has;
  }

  public function indexOfLaboratory($aLaboratory)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->laboratories as $laboratory)
    {
      if ($laboratory->equals($aLaboratory))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getJob_index($index)
  {
    $aJob = $this->jobs[$index];
    return $aJob;
  }

  public function getJobs()
  {
    $newJobs = $this->jobs;
    return $newJobs;
  }

  public function numberOfJobs()
  {
    $number = count($this->jobs);
    return $number;
  }

  public function hasJobs()
  {
    $has = $this->numberOfJobs() > 0;
    return $has;
  }

  public function indexOfJob($aJob)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->jobs as $job)
    {
      if ($job->equals($aJob))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfTutorials()
  {
    return 0;
  }

  public function addTutorial($aTutorial)
  {
    $wasAdded = false;
    if ($this->indexOfTutorial($aTutorial) !== -1) { return false; }
    $this->tutorials[] = $aTutorial;
    if ($aTutorial->indexOfCourse($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aTutorial->addCourse($this);
      if (!$wasAdded)
      {
        array_pop($this->tutorials);
      }
    }
    return $wasAdded;
  }

  public function removeTutorial($aTutorial)
  {
    $wasRemoved = false;
    if ($this->indexOfTutorial($aTutorial) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfTutorial($aTutorial);
    unset($this->tutorials[$oldIndex]);
    if ($aTutorial->indexOfCourse($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aTutorial->removeCourse($this);
      if (!$wasRemoved)
      {
        $this->tutorials[$oldIndex] = $aTutorial;
        ksort($this->tutorials);
      }
    }
    $this->tutorials = array_values($this->tutorials);
    return $wasRemoved;
  }

  public function addTutorialAt($aTutorial, $index)
  {  
    $wasAdded = false;
    if($this->addTutorial($aTutorial))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTutorials()) { $index = $this->numberOfTutorials() - 1; }
      array_splice($this->tutorials, $this->indexOfTutorial($aTutorial), 1);
      array_splice($this->tutorials, $index, 0, array($aTutorial));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveTutorialAt($aTutorial, $index)
  {
    $wasAdded = false;
    if($this->indexOfTutorial($aTutorial) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfTutorials()) { $index = $this->numberOfTutorials() - 1; }
      array_splice($this->tutorials, $this->indexOfTutorial($aTutorial), 1);
      array_splice($this->tutorials, $index, 0, array($aTutorial));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addTutorialAt($aTutorial, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfLaboratories()
  {
    return 0;
  }

  public function addLaboratory($aLaboratory)
  {
    $wasAdded = false;
    if ($this->indexOfLaboratory($aLaboratory) !== -1) { return false; }
    $this->laboratories[] = $aLaboratory;
    if ($aLaboratory->indexOfCourse($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aLaboratory->addCourse($this);
      if (!$wasAdded)
      {
        array_pop($this->laboratories);
      }
    }
    return $wasAdded;
  }

  public function removeLaboratory($aLaboratory)
  {
    $wasRemoved = false;
    if ($this->indexOfLaboratory($aLaboratory) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfLaboratory($aLaboratory);
    unset($this->laboratories[$oldIndex]);
    if ($aLaboratory->indexOfCourse($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aLaboratory->removeCourse($this);
      if (!$wasRemoved)
      {
        $this->laboratories[$oldIndex] = $aLaboratory;
        ksort($this->laboratories);
      }
    }
    $this->laboratories = array_values($this->laboratories);
    return $wasRemoved;
  }

  public function addLaboratoryAt($aLaboratory, $index)
  {  
    $wasAdded = false;
    if($this->addLaboratory($aLaboratory))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfLaboratories()) { $index = $this->numberOfLaboratories() - 1; }
      array_splice($this->laboratories, $this->indexOfLaboratory($aLaboratory), 1);
      array_splice($this->laboratories, $index, 0, array($aLaboratory));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveLaboratoryAt($aLaboratory, $index)
  {
    $wasAdded = false;
    if($this->indexOfLaboratory($aLaboratory) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfLaboratories()) { $index = $this->numberOfLaboratories() - 1; }
      array_splice($this->laboratories, $this->indexOfLaboratory($aLaboratory), 1);
      array_splice($this->laboratories, $index, 0, array($aLaboratory));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addLaboratoryAt($aLaboratory, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfJobs()
  {
    return 0;
  }

  public function addJob($aJob)
  {
    $wasAdded = false;
    if ($this->indexOfJob($aJob) !== -1) { return false; }
    $this->jobs[] = $aJob;
    if ($aJob->indexOfCourse($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aJob->addCourse($this);
      if (!$wasAdded)
      {
        array_pop($this->jobs);
      }
    }
    return $wasAdded;
  }

  public function removeJob($aJob)
  {
    $wasRemoved = false;
    if ($this->indexOfJob($aJob) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfJob($aJob);
    unset($this->jobs[$oldIndex]);
    if ($aJob->indexOfCourse($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aJob->removeCourse($this);
      if (!$wasRemoved)
      {
        $this->jobs[$oldIndex] = $aJob;
        ksort($this->jobs);
      }
    }
    $this->jobs = array_values($this->jobs);
    return $wasRemoved;
  }

  public function addJobAt($aJob, $index)
  {  
    $wasAdded = false;
    if($this->addJob($aJob))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfJobs()) { $index = $this->numberOfJobs() - 1; }
      array_splice($this->jobs, $this->indexOfJob($aJob), 1);
      array_splice($this->jobs, $index, 0, array($aJob));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveJobAt($aJob, $index)
  {
    $wasAdded = false;
    if($this->indexOfJob($aJob) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfJobs()) { $index = $this->numberOfJobs() - 1; }
      array_splice($this->jobs, $this->indexOfJob($aJob), 1);
      array_splice($this->jobs, $index, 0, array($aJob));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addJobAt($aJob, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    while (count($this->tutorials) > 0)
    {
      $aTutorial = $this->tutorials[count($this->tutorials) - 1];
      $aTutorial->delete();
      unset($this->tutorials[$this->indexOfTutorial($aTutorial)]);
      $this->tutorials = array_values($this->tutorials);
    }
    
    while (count($this->laboratories) > 0)
    {
      $aLaboratory = $this->laboratories[count($this->laboratories) - 1];
      $aLaboratory->delete();
      unset($this->laboratories[$this->indexOfLaboratory($aLaboratory)]);
      $this->laboratories = array_values($this->laboratories);
    }
    
    while (count($this->jobs) > 0)
    {
      $aJob = $this->jobs[count($this->jobs) - 1];
      $aJob->delete();
      unset($this->jobs[$this->indexOfJob($aJob)]);
      $this->jobs = array_values($this->jobs);
    }
    
  }

}
?>