<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

class Job
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static $nextId = 1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Job Attributes

  /**
   * cuz the pay is so big we need a double
   */
  private $salary;
  private $requirements;
  private $requiredTime;

  //Autounique Attributes
  private $id;

  //Job State Machines
  private static $PositionTA = 1;
  private static $PositionGRADER = 2;
  private $position;

  //Job Associations
  private $course;
  private $students;
  private $jobManager;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aSalary, $aRequirements, $aRequiredTime, $aJobManager)
  {
    $this->salary = $aSalary;
    $this->requirements = $aRequirements;
    $this->requiredTime = $aRequiredTime;
    $this->id = self::$nextId++;
    $this->course = array();
    $this->students = array();
    $didAddJobManager = $this->setJobManager($aJobManager);
    if (!$didAddJobManager)
    {
      throw new Exception("Unable to create job due to jobManager");
    }
    $this->setPosition(self::$PositionTA);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function getSalary()
  {
    return $this->salary;
  }

  public function getRequirements()
  {
    return $this->requirements;
  }

  public function getRequiredTime()
  {
    return $this->requiredTime;
  }

  public function getId()
  {
    return $this->id;
  }

  public function getPositionFullName()
  {
    $answer = $this->getPosition();
    return $answer;
  }

  public function getPosition()
  {
    if ($this->position == self::$PositionTA) { return "PositionTA"; }
    elseif ($this->position == self::$PositionGRADER) { return "PositionGRADER"; }
    return null;
  }

  public function setPosition($aPosition)
  {
    if ($aPosition == "PositionTA" || $aPosition == self::$PositionTA)
    {
      $this->position = self::$PositionTA;
      return true;
    }
    elseif ($aPosition == "PositionGRADER" || $aPosition == self::$PositionGRADER)
    {
      $this->position = self::$PositionGRADER;
      return true;
    }
    else
    {
      return false;
    }
  }

  public function getCourse_index($index)
  {
    $aCourse = $this->course[$index];
    return $aCourse;
  }

  public function getCourse()
  {
    $newCourse = $this->course;
    return $newCourse;
  }

  public function numberOfCourse()
  {
    $number = count($this->course);
    return $number;
  }

  public function hasCourse()
  {
    $has = $this->numberOfCourse() > 0;
    return $has;
  }

  public function indexOfCourse($aCourse)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->course as $course)
    {
      if ($course->equals($aCourse))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getStudent_index($index)
  {
    $aStudent = $this->students[$index];
    return $aStudent;
  }

  public function getStudents()
  {
    $newStudents = $this->students;
    return $newStudents;
  }

  public function numberOfStudents()
  {
    $number = count($this->students);
    return $number;
  }

  public function hasStudents()
  {
    $has = $this->numberOfStudents() > 0;
    return $has;
  }

  public function indexOfStudent($aStudent)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->students as $student)
    {
      if ($student->equals($aStudent))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getJobManager()
  {
    return $this->jobManager;
  }

  public static function minimumNumberOfCourse()
  {
    return 0;
  }

  public function addCourse($aCourse)
  {
    $wasAdded = false;
    if ($this->indexOfCourse($aCourse) !== -1) { return false; }
    $this->course[] = $aCourse;
    if ($aCourse->indexOfJob($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aCourse->addJob($this);
      if (!$wasAdded)
      {
        array_pop($this->course);
      }
    }
    return $wasAdded;
  }

  public function removeCourse($aCourse)
  {
    $wasRemoved = false;
    if ($this->indexOfCourse($aCourse) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfCourse($aCourse);
    unset($this->course[$oldIndex]);
    if ($aCourse->indexOfJob($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aCourse->removeJob($this);
      if (!$wasRemoved)
      {
        $this->course[$oldIndex] = $aCourse;
        ksort($this->course);
      }
    }
    $this->course = array_values($this->course);
    return $wasRemoved;
  }

  public function addCourseAt($aCourse, $index)
  {  
    $wasAdded = false;
    if($this->addCourse($aCourse))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfCourse()) { $index = $this->numberOfCourse() - 1; }
      array_splice($this->course, $this->indexOfCourse($aCourse), 1);
      array_splice($this->course, $index, 0, array($aCourse));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveCourseAt($aCourse, $index)
  {
    $wasAdded = false;
    if($this->indexOfCourse($aCourse) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfCourse()) { $index = $this->numberOfCourse() - 1; }
      array_splice($this->course, $this->indexOfCourse($aCourse), 1);
      array_splice($this->course, $index, 0, array($aCourse));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addCourseAt($aCourse, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfStudents()
  {
    return 0;
  }

  public function addStudent($aStudent)
  {
    $wasAdded = false;
    if ($this->indexOfStudent($aStudent) !== -1) { return false; }
    $this->students[] = $aStudent;
    if ($aStudent->indexOfJob($this) != -1)
    {
      $wasAdded = true;
    }
    else
    {
      $wasAdded = $aStudent->addJob($this);
      if (!$wasAdded)
      {
        array_pop($this->students);
      }
    }
    return $wasAdded;
  }

  public function removeStudent($aStudent)
  {
    $wasRemoved = false;
    if ($this->indexOfStudent($aStudent) == -1)
    {
      return $wasRemoved;
    }

    $oldIndex = $this->indexOfStudent($aStudent);
    unset($this->students[$oldIndex]);
    if ($aStudent->indexOfJob($this) == -1)
    {
      $wasRemoved = true;
    }
    else
    {
      $wasRemoved = $aStudent->removeJob($this);
      if (!$wasRemoved)
      {
        $this->students[$oldIndex] = $aStudent;
        ksort($this->students);
      }
    }
    $this->students = array_values($this->students);
    return $wasRemoved;
  }

  public function addStudentAt($aStudent, $index)
  {  
    $wasAdded = false;
    if($this->addStudent($aStudent))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfStudents()) { $index = $this->numberOfStudents() - 1; }
      array_splice($this->students, $this->indexOfStudent($aStudent), 1);
      array_splice($this->students, $index, 0, array($aStudent));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveStudentAt($aStudent, $index)
  {
    $wasAdded = false;
    if($this->indexOfStudent($aStudent) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfStudents()) { $index = $this->numberOfStudents() - 1; }
      array_splice($this->students, $this->indexOfStudent($aStudent), 1);
      array_splice($this->students, $index, 0, array($aStudent));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addStudentAt($aStudent, $index);
    }
    return $wasAdded;
  }

  public function setJobManager($aJobManager)
  {
    $wasSet = false;
    if ($aJobManager == null)
    {
      return $wasSet;
    }
    
    $existingJobManager = $this->jobManager;
    $this->jobManager = $aJobManager;
    if ($existingJobManager != null && $existingJobManager != $aJobManager)
    {
      $existingJobManager->removeJob($this);
    }
    $this->jobManager->addJob($this);
    $wasSet = true;
    return $wasSet;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $copyOfCourse = $this->course;
    $this->course = array();
    foreach ($copyOfCourse as $aCourse)
    {
      $aCourse->removeJob($this);
    }
    $copyOfStudents = $this->students;
    $this->students = array();
    foreach ($copyOfStudents as $aStudent)
    {
      $aStudent->removeJob($this);
    }
    $placeholderJobManager = $this->jobManager;
    $this->jobManager = null;
    $placeholderJobManager->removeJob($this);
  }

}
?>