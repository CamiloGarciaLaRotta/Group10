<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

// mimic the registrationManager,
// oversee all job posting/application transactions
class JobManager
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static $theInstance = null;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //JobManager Associations
  private $jobs;
  private $admins;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private function __construct()
  {
    $this->jobs = array();
    $this->admins = array();
  }

  public static function getInstance()
  {
    if(self::$theInstance == null)
    {
      self::$theInstance = new JobManager();
    }
    return self::$theInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function getJob_index($index)
  {
    $aJob = $this->jobs[$index];
    return $aJob;
  }

  public function getJobs()
  {
    $newJobs = $this->jobs;
    return $newJobs;
  }

  public function numberOfJobs()
  {
    $number = count($this->jobs);
    return $number;
  }

  public function hasJobs()
  {
    $has = $this->numberOfJobs() > 0;
    return $has;
  }

  public function indexOfJob($aJob)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->jobs as $job)
    {
      if ($job->equals($aJob))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public function getAdmin_index($index)
  {
    $aAdmin = $this->admins[$index];
    return $aAdmin;
  }

  public function getAdmins()
  {
    $newAdmins = $this->admins;
    return $newAdmins;
  }

  public function numberOfAdmins()
  {
    $number = count($this->admins);
    return $number;
  }

  public function hasAdmins()
  {
    $has = $this->numberOfAdmins() > 0;
    return $has;
  }

  public function indexOfAdmin($aAdmin)
  {
    $wasFound = false;
    $index = 0;
    foreach($this->admins as $admin)
    {
      if ($admin->equals($aAdmin))
      {
        $wasFound = true;
        break;
      }
      $index += 1;
    }
    $index = $wasFound ? $index : -1;
    return $index;
  }

  public static function minimumNumberOfJobs()
  {
    return 0;
  }

  public function addJobVia($aSalary, $aRequirements, $aRequiredTime, $aInstructor)
  {
    return new Job($aSalary, $aRequirements, $aRequiredTime, $aInstructor, $this);
  }

  public function addJob($aJob)
  {
    $wasAdded = false;
    if ($this->indexOfJob($aJob) !== -1) { return false; }
    $existingJobManager = $aJob->getJobManager();
    $isNewJobManager = $existingJobManager != null && $this !== $existingJobManager;
    if ($isNewJobManager)
    {
      $aJob->setJobManager($this);
    }
    else
    {
      $this->jobs[] = $aJob;
    }
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeJob($aJob)
  {
    $wasRemoved = false;
    //Unable to remove aJob, as it must always have a jobManager
    if ($this !== $aJob->getJobManager())
    {
      unset($this->jobs[$this->indexOfJob($aJob)]);
      $this->jobs = array_values($this->jobs);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addJobAt($aJob, $index)
  {  
    $wasAdded = false;
    if($this->addJob($aJob))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfJobs()) { $index = $this->numberOfJobs() - 1; }
      array_splice($this->jobs, $this->indexOfJob($aJob), 1);
      array_splice($this->jobs, $index, 0, array($aJob));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveJobAt($aJob, $index)
  {
    $wasAdded = false;
    if($this->indexOfJob($aJob) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfJobs()) { $index = $this->numberOfJobs() - 1; }
      array_splice($this->jobs, $this->indexOfJob($aJob), 1);
      array_splice($this->jobs, $index, 0, array($aJob));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addJobAt($aJob, $index);
    }
    return $wasAdded;
  }

  public static function minimumNumberOfAdmins()
  {
    return 0;
  }

  public function addAdminVia($aId, $aUsername, $aPassword, $aFirstName, $aLastName, $aProfileManager)
  {
    return new Admin($aId, $aUsername, $aPassword, $aFirstName, $aLastName, $aProfileManager, $this);
  }

  public function addAdmin($aAdmin)
  {
    $wasAdded = false;
    if ($this->indexOfAdmin($aAdmin) !== -1) { return false; }
    $existingJobManagers = $aAdmin->getJobManagers();
    $isNewJobManagers = $existingJobManagers != null && $this !== $existingJobManagers;
    if ($isNewJobManagers)
    {
      $aAdmin->setJobManagers($this);
    }
    else
    {
      $this->admins[] = $aAdmin;
    }
    $wasAdded = true;
    return $wasAdded;
  }

  public function removeAdmin($aAdmin)
  {
    $wasRemoved = false;
    //Unable to remove aAdmin, as it must always have a jobManagers
    if ($this !== $aAdmin->getJobManagers())
    {
      unset($this->admins[$this->indexOfAdmin($aAdmin)]);
      $this->admins = array_values($this->admins);
      $wasRemoved = true;
    }
    return $wasRemoved;
  }

  public function addAdminAt($aAdmin, $index)
  {  
    $wasAdded = false;
    if($this->addAdmin($aAdmin))
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfAdmins()) { $index = $this->numberOfAdmins() - 1; }
      array_splice($this->admins, $this->indexOfAdmin($aAdmin), 1);
      array_splice($this->admins, $index, 0, array($aAdmin));
      $wasAdded = true;
    }
    return $wasAdded;
  }

  public function addOrMoveAdminAt($aAdmin, $index)
  {
    $wasAdded = false;
    if($this->indexOfAdmin($aAdmin) !== -1)
    {
      if($index < 0 ) { $index = 0; }
      if($index > $this->numberOfAdmins()) { $index = $this->numberOfAdmins() - 1; }
      array_splice($this->admins, $this->indexOfAdmin($aAdmin), 1);
      array_splice($this->admins, $index, 0, array($aAdmin));
      $wasAdded = true;
    } 
    else 
    {
      $wasAdded = $this->addAdminAt($aAdmin, $index);
    }
    return $wasAdded;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    while (count($this->jobs) > 0)
    {
      $aJob = $this->jobs[count($this->jobs) - 1];
      $aJob->delete();
      unset($this->jobs[$this->indexOfJob($aJob)]);
      $this->jobs = array_values($this->jobs);
    }
    
    while (count($this->admins) > 0)
    {
      $aAdmin = $this->admins[count($this->admins) - 1];
      $aAdmin->delete();
      unset($this->admins[$this->indexOfAdmin($aAdmin)]);
      $this->admins = array_values($this->admins);
    }
    
  }

}
?>