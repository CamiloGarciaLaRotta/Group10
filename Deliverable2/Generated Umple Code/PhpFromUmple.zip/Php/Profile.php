<?php
/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

class Profile
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Profile Attributes

  /**
   * either student or employee ID, for the securities yo
   */
  private $id;
  private $username;
  private $password;
  private $firstName;
  private $lastName;

  //Profile Associations
  private $profileManager;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public function __construct($aId, $aUsername, $aPassword, $aFirstName, $aLastName, $aProfileManager)
  {
    $this->id = $aId;
    $this->username = $aUsername;
    $this->password = $aPassword;
    $this->firstName = $aFirstName;
    $this->lastName = $aLastName;
    $didAddProfileManager = $this->setProfileManager($aProfileManager);
    if (!$didAddProfileManager)
    {
      throw new Exception("Unable to create userProfile due to profileManager");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public function setUsername($aUsername)
  {
    $wasSet = false;
    $this->username = $aUsername;
    $wasSet = true;
    return $wasSet;
  }

  public function setPassword($aPassword)
  {
    $wasSet = false;
    $this->password = $aPassword;
    $wasSet = true;
    return $wasSet;
  }

  public function setFirstName($aFirstName)
  {
    $wasSet = false;
    $this->firstName = $aFirstName;
    $wasSet = true;
    return $wasSet;
  }

  public function setLastName($aLastName)
  {
    $wasSet = false;
    $this->lastName = $aLastName;
    $wasSet = true;
    return $wasSet;
  }

  public function getId()
  {
    return $this->id;
  }

  public function getUsername()
  {
    return $this->username;
  }

  public function getPassword()
  {
    return $this->password;
  }

  public function getFirstName()
  {
    return $this->firstName;
  }

  public function getLastName()
  {
    return $this->lastName;
  }

  public function getProfileManager()
  {
    return $this->profileManager;
  }

  public function setProfileManager($aProfileManager)
  {
    $wasSet = false;
    if ($aProfileManager == null)
    {
      return $wasSet;
    }
    
    $existingProfileManager = $this->profileManager;
    $this->profileManager = $aProfileManager;
    if ($existingProfileManager != null && $existingProfileManager != $aProfileManager)
    {
      $existingProfileManager->removeUserProfile($this);
    }
    $this->profileManager->addUserProfile($this);
    $wasSet = true;
    return $wasSet;
  }

  public function equals($compareTo)
  {
    return $this == $compareTo;
  }

  public function delete()
  {
    $placeholderProfileManager = $this->profileManager;
    $this->profileManager = null;
    $placeholderProfileManager->removeUserProfile($this);
  }

}
?>