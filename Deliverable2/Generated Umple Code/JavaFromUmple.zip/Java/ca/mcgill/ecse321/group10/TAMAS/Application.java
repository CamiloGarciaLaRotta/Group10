/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.util.*;

// line 59 "../../../../../../../../ump/tmp744573/model.ump"
// line 121 "../../../../../../../../ump/tmp744573/model.ump"
public class Application
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static int nextId = 1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Application Attributes
  private int postingID;

  //Autounique Attributes
  private int id;

  //Application Associations
  private List<Student> student;
  private List<Instructor> instructors;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Application(int aPostingID)
  {
    postingID = aPostingID;
    id = nextId++;
    student = new ArrayList<Student>();
    instructors = new ArrayList<Instructor>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setPostingID(int aPostingID)
  {
    boolean wasSet = false;
    postingID = aPostingID;
    wasSet = true;
    return wasSet;
  }

  public int getPostingID()
  {
    return postingID;
  }

  public int getId()
  {
    return id;
  }

  public Student getStudent(int index)
  {
    Student aStudent = student.get(index);
    return aStudent;
  }

  public List<Student> getStudent()
  {
    List<Student> newStudent = Collections.unmodifiableList(student);
    return newStudent;
  }

  public int numberOfStudent()
  {
    int number = student.size();
    return number;
  }

  public boolean hasStudent()
  {
    boolean has = student.size() > 0;
    return has;
  }

  public int indexOfStudent(Student aStudent)
  {
    int index = student.indexOf(aStudent);
    return index;
  }

  public Instructor getInstructor(int index)
  {
    Instructor aInstructor = instructors.get(index);
    return aInstructor;
  }

  public List<Instructor> getInstructors()
  {
    List<Instructor> newInstructors = Collections.unmodifiableList(instructors);
    return newInstructors;
  }

  public int numberOfInstructors()
  {
    int number = instructors.size();
    return number;
  }

  public boolean hasInstructors()
  {
    boolean has = instructors.size() > 0;
    return has;
  }

  public int indexOfInstructor(Instructor aInstructor)
  {
    int index = instructors.indexOf(aInstructor);
    return index;
  }

  public static int minimumNumberOfStudent()
  {
    return 0;
  }

  public boolean addStudent(Student aStudent)
  {
    boolean wasAdded = false;
    if (student.contains(aStudent)) { return false; }
    student.add(aStudent);
    if (aStudent.indexOfApplication(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aStudent.addApplication(this);
      if (!wasAdded)
      {
        student.remove(aStudent);
      }
    }
    return wasAdded;
  }

  public boolean removeStudent(Student aStudent)
  {
    boolean wasRemoved = false;
    if (!student.contains(aStudent))
    {
      return wasRemoved;
    }

    int oldIndex = student.indexOf(aStudent);
    student.remove(oldIndex);
    if (aStudent.indexOfApplication(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aStudent.removeApplication(this);
      if (!wasRemoved)
      {
        student.add(oldIndex,aStudent);
      }
    }
    return wasRemoved;
  }

  public boolean addStudentAt(Student aStudent, int index)
  {  
    boolean wasAdded = false;
    if(addStudent(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudent()) { index = numberOfStudent() - 1; }
      student.remove(aStudent);
      student.add(index, aStudent);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveStudentAt(Student aStudent, int index)
  {
    boolean wasAdded = false;
    if(student.contains(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudent()) { index = numberOfStudent() - 1; }
      student.remove(aStudent);
      student.add(index, aStudent);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addStudentAt(aStudent, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfInstructors()
  {
    return 0;
  }

  public boolean addInstructor(Instructor aInstructor)
  {
    boolean wasAdded = false;
    if (instructors.contains(aInstructor)) { return false; }
    instructors.add(aInstructor);
    if (aInstructor.indexOfApplication(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aInstructor.addApplication(this);
      if (!wasAdded)
      {
        instructors.remove(aInstructor);
      }
    }
    return wasAdded;
  }

  public boolean removeInstructor(Instructor aInstructor)
  {
    boolean wasRemoved = false;
    if (!instructors.contains(aInstructor))
    {
      return wasRemoved;
    }

    int oldIndex = instructors.indexOf(aInstructor);
    instructors.remove(oldIndex);
    if (aInstructor.indexOfApplication(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aInstructor.removeApplication(this);
      if (!wasRemoved)
      {
        instructors.add(oldIndex,aInstructor);
      }
    }
    return wasRemoved;
  }

  public boolean addInstructorAt(Instructor aInstructor, int index)
  {  
    boolean wasAdded = false;
    if(addInstructor(aInstructor))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfInstructors()) { index = numberOfInstructors() - 1; }
      instructors.remove(aInstructor);
      instructors.add(index, aInstructor);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveInstructorAt(Instructor aInstructor, int index)
  {
    boolean wasAdded = false;
    if(instructors.contains(aInstructor))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfInstructors()) { index = numberOfInstructors() - 1; }
      instructors.remove(aInstructor);
      instructors.add(index, aInstructor);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addInstructorAt(aInstructor, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    ArrayList<Student> copyOfStudent = new ArrayList<Student>(student);
    student.clear();
    for(Student aStudent : copyOfStudent)
    {
      aStudent.removeApplication(this);
    }
    ArrayList<Instructor> copyOfInstructors = new ArrayList<Instructor>(instructors);
    instructors.clear();
    for(Instructor aInstructor : copyOfInstructors)
    {
      aInstructor.removeApplication(this);
    }
  }


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "postingID" + ":" + getPostingID()+ "]";
  }
}