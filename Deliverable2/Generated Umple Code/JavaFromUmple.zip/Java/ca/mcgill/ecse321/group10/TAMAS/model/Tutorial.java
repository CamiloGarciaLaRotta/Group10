/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS.model;
import java.sql.Date;

// line 17 "../../../../../../../../../ump/tmp671288/model.ump"
// line 88 "../../../../../../../../../ump/tmp671288/model.ump"
public class Tutorial extends TimeSlot
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Tutorial(Date aStartTime, Date aEndTime, Course aCourse)
  {
    super(aStartTime, aEndTime, aCourse);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}