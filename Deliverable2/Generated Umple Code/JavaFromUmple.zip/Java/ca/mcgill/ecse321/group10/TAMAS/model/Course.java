/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS.model;
import java.util.*;
import java.sql.Date;

// line 4 "../../../../../../../../../ump/tmp671288/model.ump"
// line 77 "../../../../../../../../../ump/tmp671288/model.ump"
public class Course
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Course Attributes
  private String className;
  private String cdn;
  private float graderTimeBudget;
  private float taTimeBudget;

  //Course Associations
  private List<TimeSlot> timeslots;
  private List<Job> jobs;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Course(String aClassName, String aCdn, float aGraderTimeBudget, float aTaTimeBudget)
  {
    className = aClassName;
    cdn = aCdn;
    graderTimeBudget = aGraderTimeBudget;
    taTimeBudget = aTaTimeBudget;
    timeslots = new ArrayList<TimeSlot>();
    jobs = new ArrayList<Job>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setClassName(String aClassName)
  {
    boolean wasSet = false;
    className = aClassName;
    wasSet = true;
    return wasSet;
  }

  public boolean setGraderTimeBudget(float aGraderTimeBudget)
  {
    boolean wasSet = false;
    graderTimeBudget = aGraderTimeBudget;
    wasSet = true;
    return wasSet;
  }

  public boolean setTaTimeBudget(float aTaTimeBudget)
  {
    boolean wasSet = false;
    taTimeBudget = aTaTimeBudget;
    wasSet = true;
    return wasSet;
  }

  public String getClassName()
  {
    return className;
  }

  public String getCdn()
  {
    return cdn;
  }

  /**
   * time budget
   */
  public float getGraderTimeBudget()
  {
    return graderTimeBudget;
  }

  /**
   * time budget
   */
  public float getTaTimeBudget()
  {
    return taTimeBudget;
  }

  public TimeSlot getTimeslot(int index)
  {
    TimeSlot aTimeslot = timeslots.get(index);
    return aTimeslot;
  }

  public List<TimeSlot> getTimeslots()
  {
    List<TimeSlot> newTimeslots = Collections.unmodifiableList(timeslots);
    return newTimeslots;
  }

  public int numberOfTimeslots()
  {
    int number = timeslots.size();
    return number;
  }

  public boolean hasTimeslots()
  {
    boolean has = timeslots.size() > 0;
    return has;
  }

  public int indexOfTimeslot(TimeSlot aTimeslot)
  {
    int index = timeslots.indexOf(aTimeslot);
    return index;
  }

  public Job getJob(int index)
  {
    Job aJob = jobs.get(index);
    return aJob;
  }

  public List<Job> getJobs()
  {
    List<Job> newJobs = Collections.unmodifiableList(jobs);
    return newJobs;
  }

  public int numberOfJobs()
  {
    int number = jobs.size();
    return number;
  }

  public boolean hasJobs()
  {
    boolean has = jobs.size() > 0;
    return has;
  }

  public int indexOfJob(Job aJob)
  {
    int index = jobs.indexOf(aJob);
    return index;
  }

  public static int minimumNumberOfTimeslots()
  {
    return 0;
  }

  public TimeSlot addTimeslot(Date aStartTime, Date aEndTime)
  {
    return new TimeSlot(aStartTime, aEndTime, this);
  }

  public boolean addTimeslot(TimeSlot aTimeslot)
  {
    boolean wasAdded = false;
    if (timeslots.contains(aTimeslot)) { return false; }
    Course existingCourse = aTimeslot.getCourse();
    boolean isNewCourse = existingCourse != null && !this.equals(existingCourse);
    if (isNewCourse)
    {
      aTimeslot.setCourse(this);
    }
    else
    {
      timeslots.add(aTimeslot);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeTimeslot(TimeSlot aTimeslot)
  {
    boolean wasRemoved = false;
    //Unable to remove aTimeslot, as it must always have a course
    if (!this.equals(aTimeslot.getCourse()))
    {
      timeslots.remove(aTimeslot);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addTimeslotAt(TimeSlot aTimeslot, int index)
  {  
    boolean wasAdded = false;
    if(addTimeslot(aTimeslot))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTimeslots()) { index = numberOfTimeslots() - 1; }
      timeslots.remove(aTimeslot);
      timeslots.add(index, aTimeslot);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveTimeslotAt(TimeSlot aTimeslot, int index)
  {
    boolean wasAdded = false;
    if(timeslots.contains(aTimeslot))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTimeslots()) { index = numberOfTimeslots() - 1; }
      timeslots.remove(aTimeslot);
      timeslots.add(index, aTimeslot);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addTimeslotAt(aTimeslot, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfJobs()
  {
    return 0;
  }

  public boolean addJob(Job aJob)
  {
    boolean wasAdded = false;
    if (jobs.contains(aJob)) { return false; }
    jobs.add(aJob);
    if (aJob.indexOfCourse(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aJob.addCourse(this);
      if (!wasAdded)
      {
        jobs.remove(aJob);
      }
    }
    return wasAdded;
  }

  public boolean removeJob(Job aJob)
  {
    boolean wasRemoved = false;
    if (!jobs.contains(aJob))
    {
      return wasRemoved;
    }

    int oldIndex = jobs.indexOf(aJob);
    jobs.remove(oldIndex);
    if (aJob.indexOfCourse(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aJob.removeCourse(this);
      if (!wasRemoved)
      {
        jobs.add(oldIndex,aJob);
      }
    }
    return wasRemoved;
  }

  public boolean addJobAt(Job aJob, int index)
  {  
    boolean wasAdded = false;
    if(addJob(aJob))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfJobs()) { index = numberOfJobs() - 1; }
      jobs.remove(aJob);
      jobs.add(index, aJob);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveJobAt(Job aJob, int index)
  {
    boolean wasAdded = false;
    if(jobs.contains(aJob))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfJobs()) { index = numberOfJobs() - 1; }
      jobs.remove(aJob);
      jobs.add(index, aJob);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addJobAt(aJob, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    while (timeslots.size() > 0)
    {
      TimeSlot aTimeslot = timeslots.get(timeslots.size() - 1);
      aTimeslot.delete();
      timeslots.remove(aTimeslot);
    }
    
    while (jobs.size() > 0)
    {
      Job aJob = jobs.get(jobs.size() - 1);
      aJob.delete();
      jobs.remove(aJob);
    }
    
  }


  public String toString()
  {
    return super.toString() + "["+
            "className" + ":" + getClassName()+ "," +
            "cdn" + ":" + getCdn()+ "," +
            "graderTimeBudget" + ":" + getGraderTimeBudget()+ "," +
            "taTimeBudget" + ":" + getTaTimeBudget()+ "]";
  }
}