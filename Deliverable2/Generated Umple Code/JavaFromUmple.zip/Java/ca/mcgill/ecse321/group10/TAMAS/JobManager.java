/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.util.*;
import java.sql.Date;

/**
 * mimic the registrationManager,
 * oversee all job posting/application transactions
 */
// line 76 "../../../../../../../../ump/tmp744573/model.ump"
// line 131 "../../../../../../../../ump/tmp744573/model.ump"
public class JobManager
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static JobManager theInstance = null;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //JobManager Associations
  private List<Job> jobs;
  private List<Admin> admins;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private JobManager()
  {
    jobs = new ArrayList<Job>();
    admins = new ArrayList<Admin>();
  }

  public static JobManager getInstance()
  {
    if(theInstance == null)
    {
      theInstance = new JobManager();
    }
    return theInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Job getJob(int index)
  {
    Job aJob = jobs.get(index);
    return aJob;
  }

  public List<Job> getJobs()
  {
    List<Job> newJobs = Collections.unmodifiableList(jobs);
    return newJobs;
  }

  public int numberOfJobs()
  {
    int number = jobs.size();
    return number;
  }

  public boolean hasJobs()
  {
    boolean has = jobs.size() > 0;
    return has;
  }

  public int indexOfJob(Job aJob)
  {
    int index = jobs.indexOf(aJob);
    return index;
  }

  public Admin getAdmin(int index)
  {
    Admin aAdmin = admins.get(index);
    return aAdmin;
  }

  public List<Admin> getAdmins()
  {
    List<Admin> newAdmins = Collections.unmodifiableList(admins);
    return newAdmins;
  }

  public int numberOfAdmins()
  {
    int number = admins.size();
    return number;
  }

  public boolean hasAdmins()
  {
    boolean has = admins.size() > 0;
    return has;
  }

  public int indexOfAdmin(Admin aAdmin)
  {
    int index = admins.indexOf(aAdmin);
    return index;
  }

  public static int minimumNumberOfJobs()
  {
    return 0;
  }

  public Job addJob(double aSalary, String aRequirements, Date aRequiredTime)
  {
    return new Job(aSalary, aRequirements, aRequiredTime, this);
  }

  public boolean addJob(Job aJob)
  {
    boolean wasAdded = false;
    if (jobs.contains(aJob)) { return false; }
    JobManager existingJobManager = aJob.getJobManager();
    boolean isNewJobManager = existingJobManager != null && !this.equals(existingJobManager);
    if (isNewJobManager)
    {
      aJob.setJobManager(this);
    }
    else
    {
      jobs.add(aJob);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeJob(Job aJob)
  {
    boolean wasRemoved = false;
    //Unable to remove aJob, as it must always have a jobManager
    if (!this.equals(aJob.getJobManager()))
    {
      jobs.remove(aJob);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addJobAt(Job aJob, int index)
  {  
    boolean wasAdded = false;
    if(addJob(aJob))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfJobs()) { index = numberOfJobs() - 1; }
      jobs.remove(aJob);
      jobs.add(index, aJob);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveJobAt(Job aJob, int index)
  {
    boolean wasAdded = false;
    if(jobs.contains(aJob))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfJobs()) { index = numberOfJobs() - 1; }
      jobs.remove(aJob);
      jobs.add(index, aJob);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addJobAt(aJob, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfAdmins()
  {
    return 0;
  }

  public Admin addAdmin(String aId, String aUsername, String aPassword, String aFirstName, String aLastName, ProfileManager aProfileManager)
  {
    return new Admin(aId, aUsername, aPassword, aFirstName, aLastName, aProfileManager, this);
  }

  public boolean addAdmin(Admin aAdmin)
  {
    boolean wasAdded = false;
    if (admins.contains(aAdmin)) { return false; }
    JobManager existingJobManagers = aAdmin.getJobManagers();
    boolean isNewJobManagers = existingJobManagers != null && !this.equals(existingJobManagers);
    if (isNewJobManagers)
    {
      aAdmin.setJobManagers(this);
    }
    else
    {
      admins.add(aAdmin);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeAdmin(Admin aAdmin)
  {
    boolean wasRemoved = false;
    //Unable to remove aAdmin, as it must always have a jobManagers
    if (!this.equals(aAdmin.getJobManagers()))
    {
      admins.remove(aAdmin);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addAdminAt(Admin aAdmin, int index)
  {  
    boolean wasAdded = false;
    if(addAdmin(aAdmin))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfAdmins()) { index = numberOfAdmins() - 1; }
      admins.remove(aAdmin);
      admins.add(index, aAdmin);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveAdminAt(Admin aAdmin, int index)
  {
    boolean wasAdded = false;
    if(admins.contains(aAdmin))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfAdmins()) { index = numberOfAdmins() - 1; }
      admins.remove(aAdmin);
      admins.add(index, aAdmin);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addAdminAt(aAdmin, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    while (jobs.size() > 0)
    {
      Job aJob = jobs.get(jobs.size() - 1);
      aJob.delete();
      jobs.remove(aJob);
    }
    
    while (admins.size() > 0)
    {
      Admin aAdmin = admins.get(admins.size() - 1);
      aAdmin.delete();
      admins.remove(aAdmin);
    }
    
  }

}