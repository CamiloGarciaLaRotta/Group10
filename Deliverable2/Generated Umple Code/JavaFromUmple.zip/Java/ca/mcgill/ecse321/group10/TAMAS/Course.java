/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.util.*;

// line 4 "../../../../../../../../ump/tmp744573/model.ump"
// line 86 "../../../../../../../../ump/tmp744573/model.ump"
public class Course
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Course Attributes
  private String className;
  private String cdn;
  private float graderTimeBudget;
  private float taTimeBudget;

  //Course Associations
  private List<Tutorial> tutorials;
  private List<Laboratory> laboratories;
  private List<Job> jobs;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Course(String aClassName, String aCdn, float aGraderTimeBudget, float aTaTimeBudget)
  {
    className = aClassName;
    cdn = aCdn;
    graderTimeBudget = aGraderTimeBudget;
    taTimeBudget = aTaTimeBudget;
    tutorials = new ArrayList<Tutorial>();
    laboratories = new ArrayList<Laboratory>();
    jobs = new ArrayList<Job>();
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setClassName(String aClassName)
  {
    boolean wasSet = false;
    className = aClassName;
    wasSet = true;
    return wasSet;
  }

  public boolean setGraderTimeBudget(float aGraderTimeBudget)
  {
    boolean wasSet = false;
    graderTimeBudget = aGraderTimeBudget;
    wasSet = true;
    return wasSet;
  }

  public boolean setTaTimeBudget(float aTaTimeBudget)
  {
    boolean wasSet = false;
    taTimeBudget = aTaTimeBudget;
    wasSet = true;
    return wasSet;
  }

  public String getClassName()
  {
    return className;
  }

  public String getCdn()
  {
    return cdn;
  }

  /**
   * time budget
   */
  public float getGraderTimeBudget()
  {
    return graderTimeBudget;
  }

  /**
   * time budget
   */
  public float getTaTimeBudget()
  {
    return taTimeBudget;
  }

  public Tutorial getTutorial(int index)
  {
    Tutorial aTutorial = tutorials.get(index);
    return aTutorial;
  }

  public List<Tutorial> getTutorials()
  {
    List<Tutorial> newTutorials = Collections.unmodifiableList(tutorials);
    return newTutorials;
  }

  public int numberOfTutorials()
  {
    int number = tutorials.size();
    return number;
  }

  public boolean hasTutorials()
  {
    boolean has = tutorials.size() > 0;
    return has;
  }

  public int indexOfTutorial(Tutorial aTutorial)
  {
    int index = tutorials.indexOf(aTutorial);
    return index;
  }

  public Laboratory getLaboratory(int index)
  {
    Laboratory aLaboratory = laboratories.get(index);
    return aLaboratory;
  }

  public List<Laboratory> getLaboratories()
  {
    List<Laboratory> newLaboratories = Collections.unmodifiableList(laboratories);
    return newLaboratories;
  }

  public int numberOfLaboratories()
  {
    int number = laboratories.size();
    return number;
  }

  public boolean hasLaboratories()
  {
    boolean has = laboratories.size() > 0;
    return has;
  }

  public int indexOfLaboratory(Laboratory aLaboratory)
  {
    int index = laboratories.indexOf(aLaboratory);
    return index;
  }

  public Job getJob(int index)
  {
    Job aJob = jobs.get(index);
    return aJob;
  }

  public List<Job> getJobs()
  {
    List<Job> newJobs = Collections.unmodifiableList(jobs);
    return newJobs;
  }

  public int numberOfJobs()
  {
    int number = jobs.size();
    return number;
  }

  public boolean hasJobs()
  {
    boolean has = jobs.size() > 0;
    return has;
  }

  public int indexOfJob(Job aJob)
  {
    int index = jobs.indexOf(aJob);
    return index;
  }

  public static int minimumNumberOfTutorials()
  {
    return 0;
  }

  public boolean addTutorial(Tutorial aTutorial)
  {
    boolean wasAdded = false;
    if (tutorials.contains(aTutorial)) { return false; }
    tutorials.add(aTutorial);
    if (aTutorial.indexOfCourse(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aTutorial.addCourse(this);
      if (!wasAdded)
      {
        tutorials.remove(aTutorial);
      }
    }
    return wasAdded;
  }

  public boolean removeTutorial(Tutorial aTutorial)
  {
    boolean wasRemoved = false;
    if (!tutorials.contains(aTutorial))
    {
      return wasRemoved;
    }

    int oldIndex = tutorials.indexOf(aTutorial);
    tutorials.remove(oldIndex);
    if (aTutorial.indexOfCourse(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aTutorial.removeCourse(this);
      if (!wasRemoved)
      {
        tutorials.add(oldIndex,aTutorial);
      }
    }
    return wasRemoved;
  }

  public boolean addTutorialAt(Tutorial aTutorial, int index)
  {  
    boolean wasAdded = false;
    if(addTutorial(aTutorial))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTutorials()) { index = numberOfTutorials() - 1; }
      tutorials.remove(aTutorial);
      tutorials.add(index, aTutorial);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveTutorialAt(Tutorial aTutorial, int index)
  {
    boolean wasAdded = false;
    if(tutorials.contains(aTutorial))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfTutorials()) { index = numberOfTutorials() - 1; }
      tutorials.remove(aTutorial);
      tutorials.add(index, aTutorial);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addTutorialAt(aTutorial, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfLaboratories()
  {
    return 0;
  }

  public boolean addLaboratory(Laboratory aLaboratory)
  {
    boolean wasAdded = false;
    if (laboratories.contains(aLaboratory)) { return false; }
    laboratories.add(aLaboratory);
    if (aLaboratory.indexOfCourse(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aLaboratory.addCourse(this);
      if (!wasAdded)
      {
        laboratories.remove(aLaboratory);
      }
    }
    return wasAdded;
  }

  public boolean removeLaboratory(Laboratory aLaboratory)
  {
    boolean wasRemoved = false;
    if (!laboratories.contains(aLaboratory))
    {
      return wasRemoved;
    }

    int oldIndex = laboratories.indexOf(aLaboratory);
    laboratories.remove(oldIndex);
    if (aLaboratory.indexOfCourse(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aLaboratory.removeCourse(this);
      if (!wasRemoved)
      {
        laboratories.add(oldIndex,aLaboratory);
      }
    }
    return wasRemoved;
  }

  public boolean addLaboratoryAt(Laboratory aLaboratory, int index)
  {  
    boolean wasAdded = false;
    if(addLaboratory(aLaboratory))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfLaboratories()) { index = numberOfLaboratories() - 1; }
      laboratories.remove(aLaboratory);
      laboratories.add(index, aLaboratory);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveLaboratoryAt(Laboratory aLaboratory, int index)
  {
    boolean wasAdded = false;
    if(laboratories.contains(aLaboratory))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfLaboratories()) { index = numberOfLaboratories() - 1; }
      laboratories.remove(aLaboratory);
      laboratories.add(index, aLaboratory);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addLaboratoryAt(aLaboratory, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfJobs()
  {
    return 0;
  }

  public boolean addJob(Job aJob)
  {
    boolean wasAdded = false;
    if (jobs.contains(aJob)) { return false; }
    jobs.add(aJob);
    if (aJob.indexOfCourse(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aJob.addCourse(this);
      if (!wasAdded)
      {
        jobs.remove(aJob);
      }
    }
    return wasAdded;
  }

  public boolean removeJob(Job aJob)
  {
    boolean wasRemoved = false;
    if (!jobs.contains(aJob))
    {
      return wasRemoved;
    }

    int oldIndex = jobs.indexOf(aJob);
    jobs.remove(oldIndex);
    if (aJob.indexOfCourse(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aJob.removeCourse(this);
      if (!wasRemoved)
      {
        jobs.add(oldIndex,aJob);
      }
    }
    return wasRemoved;
  }

  public boolean addJobAt(Job aJob, int index)
  {  
    boolean wasAdded = false;
    if(addJob(aJob))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfJobs()) { index = numberOfJobs() - 1; }
      jobs.remove(aJob);
      jobs.add(index, aJob);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveJobAt(Job aJob, int index)
  {
    boolean wasAdded = false;
    if(jobs.contains(aJob))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfJobs()) { index = numberOfJobs() - 1; }
      jobs.remove(aJob);
      jobs.add(index, aJob);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addJobAt(aJob, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    while (tutorials.size() > 0)
    {
      Tutorial aTutorial = tutorials.get(tutorials.size() - 1);
      aTutorial.delete();
      tutorials.remove(aTutorial);
    }
    
    while (laboratories.size() > 0)
    {
      Laboratory aLaboratory = laboratories.get(laboratories.size() - 1);
      aLaboratory.delete();
      laboratories.remove(aLaboratory);
    }
    
    while (jobs.size() > 0)
    {
      Job aJob = jobs.get(jobs.size() - 1);
      aJob.delete();
      jobs.remove(aJob);
    }
    
  }


  public String toString()
  {
    return super.toString() + "["+
            "className" + ":" + getClassName()+ "," +
            "cdn" + ":" + getCdn()+ "," +
            "graderTimeBudget" + ":" + getGraderTimeBudget()+ "," +
            "taTimeBudget" + ":" + getTaTimeBudget()+ "]";
  }
}