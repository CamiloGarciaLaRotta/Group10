/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;

// line 39 "../../../../../../../../ump/tmp744573/model.ump"
// line 111 "../../../../../../../../ump/tmp744573/model.ump"
public class Profile
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Profile Attributes
  private String id;
  private String username;
  private String password;
  private String firstName;
  private String lastName;

  //Profile Associations
  private ProfileManager profileManager;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Profile(String aId, String aUsername, String aPassword, String aFirstName, String aLastName, ProfileManager aProfileManager)
  {
    id = aId;
    username = aUsername;
    password = aPassword;
    firstName = aFirstName;
    lastName = aLastName;
    boolean didAddProfileManager = setProfileManager(aProfileManager);
    if (!didAddProfileManager)
    {
      throw new RuntimeException("Unable to create userProfile due to profileManager");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public boolean setUsername(String aUsername)
  {
    boolean wasSet = false;
    username = aUsername;
    wasSet = true;
    return wasSet;
  }

  public boolean setPassword(String aPassword)
  {
    boolean wasSet = false;
    password = aPassword;
    wasSet = true;
    return wasSet;
  }

  public boolean setFirstName(String aFirstName)
  {
    boolean wasSet = false;
    firstName = aFirstName;
    wasSet = true;
    return wasSet;
  }

  public boolean setLastName(String aLastName)
  {
    boolean wasSet = false;
    lastName = aLastName;
    wasSet = true;
    return wasSet;
  }

  /**
   * either student or employee ID, for the securities yo
   */
  public String getId()
  {
    return id;
  }

  public String getUsername()
  {
    return username;
  }

  public String getPassword()
  {
    return password;
  }

  public String getFirstName()
  {
    return firstName;
  }

  public String getLastName()
  {
    return lastName;
  }

  public ProfileManager getProfileManager()
  {
    return profileManager;
  }

  public boolean setProfileManager(ProfileManager aProfileManager)
  {
    boolean wasSet = false;
    if (aProfileManager == null)
    {
      return wasSet;
    }

    ProfileManager existingProfileManager = profileManager;
    profileManager = aProfileManager;
    if (existingProfileManager != null && !existingProfileManager.equals(aProfileManager))
    {
      existingProfileManager.removeUserProfile(this);
    }
    profileManager.addUserProfile(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    ProfileManager placeholderProfileManager = profileManager;
    this.profileManager = null;
    placeholderProfileManager.removeUserProfile(this);
  }


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "username" + ":" + getUsername()+ "," +
            "password" + ":" + getPassword()+ "," +
            "firstName" + ":" + getFirstName()+ "," +
            "lastName" + ":" + getLastName()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "profileManager = "+(getProfileManager()!=null?Integer.toHexString(System.identityHashCode(getProfileManager())):"null");
  }
}