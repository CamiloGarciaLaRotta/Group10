/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.util.*;

// line 81 "../../../../../../../../ump/tmp744573/model.ump"
// line 136 "../../../../../../../../ump/tmp744573/model.ump"
public class ProfileManager
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static ProfileManager theInstance = null;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ProfileManager Associations
  private List<Profile> userProfiles;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private ProfileManager()
  {
    userProfiles = new ArrayList<Profile>();
  }

  public static ProfileManager getInstance()
  {
    if(theInstance == null)
    {
      theInstance = new ProfileManager();
    }
    return theInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Profile getUserProfile(int index)
  {
    Profile aUserProfile = userProfiles.get(index);
    return aUserProfile;
  }

  public List<Profile> getUserProfiles()
  {
    List<Profile> newUserProfiles = Collections.unmodifiableList(userProfiles);
    return newUserProfiles;
  }

  public int numberOfUserProfiles()
  {
    int number = userProfiles.size();
    return number;
  }

  public boolean hasUserProfiles()
  {
    boolean has = userProfiles.size() > 0;
    return has;
  }

  public int indexOfUserProfile(Profile aUserProfile)
  {
    int index = userProfiles.indexOf(aUserProfile);
    return index;
  }

  public static int minimumNumberOfUserProfiles()
  {
    return 0;
  }

  public Profile addUserProfile(String aId, String aUsername, String aPassword, String aFirstName, String aLastName)
  {
    return new Profile(aId, aUsername, aPassword, aFirstName, aLastName, this);
  }

  public boolean addUserProfile(Profile aUserProfile)
  {
    boolean wasAdded = false;
    if (userProfiles.contains(aUserProfile)) { return false; }
    ProfileManager existingProfileManager = aUserProfile.getProfileManager();
    boolean isNewProfileManager = existingProfileManager != null && !this.equals(existingProfileManager);
    if (isNewProfileManager)
    {
      aUserProfile.setProfileManager(this);
    }
    else
    {
      userProfiles.add(aUserProfile);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeUserProfile(Profile aUserProfile)
  {
    boolean wasRemoved = false;
    //Unable to remove aUserProfile, as it must always have a profileManager
    if (!this.equals(aUserProfile.getProfileManager()))
    {
      userProfiles.remove(aUserProfile);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addUserProfileAt(Profile aUserProfile, int index)
  {  
    boolean wasAdded = false;
    if(addUserProfile(aUserProfile))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfUserProfiles()) { index = numberOfUserProfiles() - 1; }
      userProfiles.remove(aUserProfile);
      userProfiles.add(index, aUserProfile);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveUserProfileAt(Profile aUserProfile, int index)
  {
    boolean wasAdded = false;
    if(userProfiles.contains(aUserProfile))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfUserProfiles()) { index = numberOfUserProfiles() - 1; }
      userProfiles.remove(aUserProfile);
      userProfiles.add(index, aUserProfile);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addUserProfileAt(aUserProfile, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    while (userProfiles.size() > 0)
    {
      Profile aUserProfile = userProfiles.get(userProfiles.size() - 1);
      aUserProfile.delete();
      userProfiles.remove(aUserProfile);
    }
    
  }

}