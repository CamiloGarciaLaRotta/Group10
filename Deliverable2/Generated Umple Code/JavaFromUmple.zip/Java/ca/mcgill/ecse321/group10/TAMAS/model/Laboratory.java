/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS.model;
import java.sql.Date;

// line 21 "../../../../../../../../../ump/tmp637989/model.ump"
// line 94 "../../../../../../../../../ump/tmp637989/model.ump"
public class Laboratory extends TimeSlot
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Laboratory(Date aStartTime, Date aEndTime, Course aCourse)
  {
    super(aStartTime, aEndTime, aCourse);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {
    super.delete();
  }

}