/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.util.*;

/**
 * unsure if class should create instances of Intrsuctor/Student
 * or rather have all the methods of Instructor/Student
 */
// line 67 "../../../../../../../../ump/tmp744573/model.ump"
// line 126 "../../../../../../../../ump/tmp744573/model.ump"
public class Admin extends Profile
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Admin Associations
  private List<Instructor> intructors;
  private List<Student> students;
  private JobManager jobManagers;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Admin(String aId, String aUsername, String aPassword, String aFirstName, String aLastName, ProfileManager aProfileManager, JobManager aJobManagers)
  {
    super(aId, aUsername, aPassword, aFirstName, aLastName, aProfileManager);
    intructors = new ArrayList<Instructor>();
    students = new ArrayList<Student>();
    boolean didAddJobManagers = setJobManagers(aJobManagers);
    if (!didAddJobManagers)
    {
      throw new RuntimeException("Unable to create admin due to jobManagers");
    }
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Instructor getIntructor(int index)
  {
    Instructor aIntructor = intructors.get(index);
    return aIntructor;
  }

  public List<Instructor> getIntructors()
  {
    List<Instructor> newIntructors = Collections.unmodifiableList(intructors);
    return newIntructors;
  }

  public int numberOfIntructors()
  {
    int number = intructors.size();
    return number;
  }

  public boolean hasIntructors()
  {
    boolean has = intructors.size() > 0;
    return has;
  }

  public int indexOfIntructor(Instructor aIntructor)
  {
    int index = intructors.indexOf(aIntructor);
    return index;
  }

  public Student getStudent(int index)
  {
    Student aStudent = students.get(index);
    return aStudent;
  }

  public List<Student> getStudents()
  {
    List<Student> newStudents = Collections.unmodifiableList(students);
    return newStudents;
  }

  public int numberOfStudents()
  {
    int number = students.size();
    return number;
  }

  public boolean hasStudents()
  {
    boolean has = students.size() > 0;
    return has;
  }

  public int indexOfStudent(Student aStudent)
  {
    int index = students.indexOf(aStudent);
    return index;
  }

  public JobManager getJobManagers()
  {
    return jobManagers;
  }

  public static int minimumNumberOfIntructors()
  {
    return 0;
  }

  public boolean addIntructor(Instructor aIntructor)
  {
    boolean wasAdded = false;
    if (intructors.contains(aIntructor)) { return false; }
    intructors.add(aIntructor);
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeIntructor(Instructor aIntructor)
  {
    boolean wasRemoved = false;
    if (intructors.contains(aIntructor))
    {
      intructors.remove(aIntructor);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addIntructorAt(Instructor aIntructor, int index)
  {  
    boolean wasAdded = false;
    if(addIntructor(aIntructor))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfIntructors()) { index = numberOfIntructors() - 1; }
      intructors.remove(aIntructor);
      intructors.add(index, aIntructor);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveIntructorAt(Instructor aIntructor, int index)
  {
    boolean wasAdded = false;
    if(intructors.contains(aIntructor))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfIntructors()) { index = numberOfIntructors() - 1; }
      intructors.remove(aIntructor);
      intructors.add(index, aIntructor);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addIntructorAt(aIntructor, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfStudents()
  {
    return 0;
  }

  public boolean addStudent(Student aStudent)
  {
    boolean wasAdded = false;
    if (students.contains(aStudent)) { return false; }
    students.add(aStudent);
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeStudent(Student aStudent)
  {
    boolean wasRemoved = false;
    if (students.contains(aStudent))
    {
      students.remove(aStudent);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addStudentAt(Student aStudent, int index)
  {  
    boolean wasAdded = false;
    if(addStudent(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudents()) { index = numberOfStudents() - 1; }
      students.remove(aStudent);
      students.add(index, aStudent);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveStudentAt(Student aStudent, int index)
  {
    boolean wasAdded = false;
    if(students.contains(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudents()) { index = numberOfStudents() - 1; }
      students.remove(aStudent);
      students.add(index, aStudent);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addStudentAt(aStudent, index);
    }
    return wasAdded;
  }

  public boolean setJobManagers(JobManager aJobManagers)
  {
    boolean wasSet = false;
    if (aJobManagers == null)
    {
      return wasSet;
    }

    JobManager existingJobManagers = jobManagers;
    jobManagers = aJobManagers;
    if (existingJobManagers != null && !existingJobManagers.equals(aJobManagers))
    {
      existingJobManagers.removeAdmin(this);
    }
    jobManagers.addAdmin(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    intructors.clear();
    students.clear();
    JobManager existingJobManagers = jobManagers;
    jobManagers = null;
    if (existingJobManagers != null)
    {
      existingJobManagers.delete();
    }
    super.delete();
  }

}