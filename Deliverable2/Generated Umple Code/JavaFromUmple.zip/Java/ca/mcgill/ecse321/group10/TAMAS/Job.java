/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-15de3ff modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.sql.Date;
import java.util.*;

// line 47 "../../../../../../../../ump/tmp744573/model.ump"
// line 116 "../../../../../../../../ump/tmp744573/model.ump"
public class Job
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static int nextId = 1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Job Attributes
  private double salary;
  private String requirements;
  private Date requiredTime;

  //Autounique Attributes
  private int id;

  //Job State Machines
  public enum Position { TA, GRADER }
  private Position position;

  //Job Associations
  private List<Course> course;
  private List<Student> students;
  private JobManager jobManager;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Job(double aSalary, String aRequirements, Date aRequiredTime, JobManager aJobManager)
  {
    salary = aSalary;
    requirements = aRequirements;
    requiredTime = aRequiredTime;
    id = nextId++;
    course = new ArrayList<Course>();
    students = new ArrayList<Student>();
    boolean didAddJobManager = setJobManager(aJobManager);
    if (!didAddJobManager)
    {
      throw new RuntimeException("Unable to create job due to jobManager");
    }
    setPosition(Position.TA);
  }

  //------------------------
  // INTERFACE
  //------------------------

  /**
   * cuz the pay is so big we need a double
   */
  public double getSalary()
  {
    return salary;
  }

  public String getRequirements()
  {
    return requirements;
  }

  public Date getRequiredTime()
  {
    return requiredTime;
  }

  public int getId()
  {
    return id;
  }

  public String getPositionFullName()
  {
    String answer = position.toString();
    return answer;
  }

  public Position getPosition()
  {
    return position;
  }

  public boolean setPosition(Position aPosition)
  {
    position = aPosition;
    return true;
  }

  public Course getCourse(int index)
  {
    Course aCourse = course.get(index);
    return aCourse;
  }

  public List<Course> getCourse()
  {
    List<Course> newCourse = Collections.unmodifiableList(course);
    return newCourse;
  }

  public int numberOfCourse()
  {
    int number = course.size();
    return number;
  }

  public boolean hasCourse()
  {
    boolean has = course.size() > 0;
    return has;
  }

  public int indexOfCourse(Course aCourse)
  {
    int index = course.indexOf(aCourse);
    return index;
  }

  public Student getStudent(int index)
  {
    Student aStudent = students.get(index);
    return aStudent;
  }

  public List<Student> getStudents()
  {
    List<Student> newStudents = Collections.unmodifiableList(students);
    return newStudents;
  }

  public int numberOfStudents()
  {
    int number = students.size();
    return number;
  }

  public boolean hasStudents()
  {
    boolean has = students.size() > 0;
    return has;
  }

  public int indexOfStudent(Student aStudent)
  {
    int index = students.indexOf(aStudent);
    return index;
  }

  public JobManager getJobManager()
  {
    return jobManager;
  }

  public static int minimumNumberOfCourse()
  {
    return 0;
  }

  public boolean addCourse(Course aCourse)
  {
    boolean wasAdded = false;
    if (course.contains(aCourse)) { return false; }
    course.add(aCourse);
    if (aCourse.indexOfJob(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aCourse.addJob(this);
      if (!wasAdded)
      {
        course.remove(aCourse);
      }
    }
    return wasAdded;
  }

  public boolean removeCourse(Course aCourse)
  {
    boolean wasRemoved = false;
    if (!course.contains(aCourse))
    {
      return wasRemoved;
    }

    int oldIndex = course.indexOf(aCourse);
    course.remove(oldIndex);
    if (aCourse.indexOfJob(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aCourse.removeJob(this);
      if (!wasRemoved)
      {
        course.add(oldIndex,aCourse);
      }
    }
    return wasRemoved;
  }

  public boolean addCourseAt(Course aCourse, int index)
  {  
    boolean wasAdded = false;
    if(addCourse(aCourse))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfCourse()) { index = numberOfCourse() - 1; }
      course.remove(aCourse);
      course.add(index, aCourse);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveCourseAt(Course aCourse, int index)
  {
    boolean wasAdded = false;
    if(course.contains(aCourse))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfCourse()) { index = numberOfCourse() - 1; }
      course.remove(aCourse);
      course.add(index, aCourse);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addCourseAt(aCourse, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfStudents()
  {
    return 0;
  }

  public boolean addStudent(Student aStudent)
  {
    boolean wasAdded = false;
    if (students.contains(aStudent)) { return false; }
    students.add(aStudent);
    if (aStudent.indexOfJob(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aStudent.addJob(this);
      if (!wasAdded)
      {
        students.remove(aStudent);
      }
    }
    return wasAdded;
  }

  public boolean removeStudent(Student aStudent)
  {
    boolean wasRemoved = false;
    if (!students.contains(aStudent))
    {
      return wasRemoved;
    }

    int oldIndex = students.indexOf(aStudent);
    students.remove(oldIndex);
    if (aStudent.indexOfJob(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aStudent.removeJob(this);
      if (!wasRemoved)
      {
        students.add(oldIndex,aStudent);
      }
    }
    return wasRemoved;
  }

  public boolean addStudentAt(Student aStudent, int index)
  {  
    boolean wasAdded = false;
    if(addStudent(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudents()) { index = numberOfStudents() - 1; }
      students.remove(aStudent);
      students.add(index, aStudent);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveStudentAt(Student aStudent, int index)
  {
    boolean wasAdded = false;
    if(students.contains(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudents()) { index = numberOfStudents() - 1; }
      students.remove(aStudent);
      students.add(index, aStudent);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addStudentAt(aStudent, index);
    }
    return wasAdded;
  }

  public boolean setJobManager(JobManager aJobManager)
  {
    boolean wasSet = false;
    if (aJobManager == null)
    {
      return wasSet;
    }

    JobManager existingJobManager = jobManager;
    jobManager = aJobManager;
    if (existingJobManager != null && !existingJobManager.equals(aJobManager))
    {
      existingJobManager.removeJob(this);
    }
    jobManager.addJob(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    ArrayList<Course> copyOfCourse = new ArrayList<Course>(course);
    course.clear();
    for(Course aCourse : copyOfCourse)
    {
      aCourse.removeJob(this);
    }
    ArrayList<Student> copyOfStudents = new ArrayList<Student>(students);
    students.clear();
    for(Student aStudent : copyOfStudents)
    {
      aStudent.removeJob(this);
    }
    JobManager placeholderJobManager = jobManager;
    this.jobManager = null;
    placeholderJobManager.removeJob(this);
  }


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "salary" + ":" + getSalary()+ "," +
            "requirements" + ":" + getRequirements()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "requiredTime" + "=" + (getRequiredTime() != null ? !getRequiredTime().equals(this)  ? getRequiredTime().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "jobManager = "+(getJobManager()!=null?Integer.toHexString(System.identityHashCode(getJobManager())):"null");
  }
}