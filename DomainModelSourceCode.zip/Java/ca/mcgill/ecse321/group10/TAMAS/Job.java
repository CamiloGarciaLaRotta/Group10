/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-89f4041 modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.sql.Date;
import java.util.*;

// line 49 "../../../../../../../../ump/tmp20095/model.ump"
// line 117 "../../../../../../../../ump/tmp20095/model.ump"
public class Job
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static int nextId = 1;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //Job Attributes
  private double salary;
  private String requirements;
  private Date requiredTime;

  //Autounique Attributes
  private int id;

  //Job State Machines
  public enum Position { TA, GRADER }
  private Position position;

  //Job Associations
  private List<Instructor> instructors;
  private List<Student> students;
  private JobManager jobManager;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public Job(double aSalary, String aRequirements, Date aRequiredTime, JobManager aJobManager)
  {
    salary = aSalary;
    requirements = aRequirements;
    requiredTime = aRequiredTime;
    id = nextId++;
    instructors = new ArrayList<Instructor>();
    students = new ArrayList<Student>();
    boolean didAddJobManager = setJobManager(aJobManager);
    if (!didAddJobManager)
    {
      throw new RuntimeException("Unable to create job due to jobManager");
    }
    setPosition(Position.TA);
  }

  //------------------------
  // INTERFACE
  //------------------------

  /**
   * cuz the pay is so big we need a double
   */
  public double getSalary()
  {
    return salary;
  }

  public String getRequirements()
  {
    return requirements;
  }

  public Date getRequiredTime()
  {
    return requiredTime;
  }

  public int getId()
  {
    return id;
  }

  public String getPositionFullName()
  {
    String answer = position.toString();
    return answer;
  }

  public Position getPosition()
  {
    return position;
  }

  public boolean setPosition(Position aPosition)
  {
    position = aPosition;
    return true;
  }

  public Instructor getInstructor(int index)
  {
    Instructor aInstructor = instructors.get(index);
    return aInstructor;
  }

  public List<Instructor> getInstructors()
  {
    List<Instructor> newInstructors = Collections.unmodifiableList(instructors);
    return newInstructors;
  }

  public int numberOfInstructors()
  {
    int number = instructors.size();
    return number;
  }

  public boolean hasInstructors()
  {
    boolean has = instructors.size() > 0;
    return has;
  }

  public int indexOfInstructor(Instructor aInstructor)
  {
    int index = instructors.indexOf(aInstructor);
    return index;
  }

  public Student getStudent(int index)
  {
    Student aStudent = students.get(index);
    return aStudent;
  }

  public List<Student> getStudents()
  {
    List<Student> newStudents = Collections.unmodifiableList(students);
    return newStudents;
  }

  public int numberOfStudents()
  {
    int number = students.size();
    return number;
  }

  public boolean hasStudents()
  {
    boolean has = students.size() > 0;
    return has;
  }

  public int indexOfStudent(Student aStudent)
  {
    int index = students.indexOf(aStudent);
    return index;
  }

  public JobManager getJobManager()
  {
    return jobManager;
  }

  public static int minimumNumberOfInstructors()
  {
    return 0;
  }

  public boolean addInstructor(Instructor aInstructor)
  {
    boolean wasAdded = false;
    if (instructors.contains(aInstructor)) { return false; }
    instructors.add(aInstructor);
    if (aInstructor.indexOfJob(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aInstructor.addJob(this);
      if (!wasAdded)
      {
        instructors.remove(aInstructor);
      }
    }
    return wasAdded;
  }

  public boolean removeInstructor(Instructor aInstructor)
  {
    boolean wasRemoved = false;
    if (!instructors.contains(aInstructor))
    {
      return wasRemoved;
    }

    int oldIndex = instructors.indexOf(aInstructor);
    instructors.remove(oldIndex);
    if (aInstructor.indexOfJob(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aInstructor.removeJob(this);
      if (!wasRemoved)
      {
        instructors.add(oldIndex,aInstructor);
      }
    }
    return wasRemoved;
  }

  public boolean addInstructorAt(Instructor aInstructor, int index)
  {  
    boolean wasAdded = false;
    if(addInstructor(aInstructor))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfInstructors()) { index = numberOfInstructors() - 1; }
      instructors.remove(aInstructor);
      instructors.add(index, aInstructor);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveInstructorAt(Instructor aInstructor, int index)
  {
    boolean wasAdded = false;
    if(instructors.contains(aInstructor))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfInstructors()) { index = numberOfInstructors() - 1; }
      instructors.remove(aInstructor);
      instructors.add(index, aInstructor);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addInstructorAt(aInstructor, index);
    }
    return wasAdded;
  }

  public static int minimumNumberOfStudents()
  {
    return 0;
  }

  public boolean addStudent(Student aStudent)
  {
    boolean wasAdded = false;
    if (students.contains(aStudent)) { return false; }
    students.add(aStudent);
    if (aStudent.indexOfJob(this) != -1)
    {
      wasAdded = true;
    }
    else
    {
      wasAdded = aStudent.addJob(this);
      if (!wasAdded)
      {
        students.remove(aStudent);
      }
    }
    return wasAdded;
  }

  public boolean removeStudent(Student aStudent)
  {
    boolean wasRemoved = false;
    if (!students.contains(aStudent))
    {
      return wasRemoved;
    }

    int oldIndex = students.indexOf(aStudent);
    students.remove(oldIndex);
    if (aStudent.indexOfJob(this) == -1)
    {
      wasRemoved = true;
    }
    else
    {
      wasRemoved = aStudent.removeJob(this);
      if (!wasRemoved)
      {
        students.add(oldIndex,aStudent);
      }
    }
    return wasRemoved;
  }

  public boolean addStudentAt(Student aStudent, int index)
  {  
    boolean wasAdded = false;
    if(addStudent(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudents()) { index = numberOfStudents() - 1; }
      students.remove(aStudent);
      students.add(index, aStudent);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveStudentAt(Student aStudent, int index)
  {
    boolean wasAdded = false;
    if(students.contains(aStudent))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfStudents()) { index = numberOfStudents() - 1; }
      students.remove(aStudent);
      students.add(index, aStudent);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addStudentAt(aStudent, index);
    }
    return wasAdded;
  }

  public boolean setJobManager(JobManager aJobManager)
  {
    boolean wasSet = false;
    if (aJobManager == null)
    {
      return wasSet;
    }

    JobManager existingJobManager = jobManager;
    jobManager = aJobManager;
    if (existingJobManager != null && !existingJobManager.equals(aJobManager))
    {
      existingJobManager.removeJob(this);
    }
    jobManager.addJob(this);
    wasSet = true;
    return wasSet;
  }

  public void delete()
  {
    ArrayList<Instructor> copyOfInstructors = new ArrayList<Instructor>(instructors);
    instructors.clear();
    for(Instructor aInstructor : copyOfInstructors)
    {
      aInstructor.removeJob(this);
    }
    ArrayList<Student> copyOfStudents = new ArrayList<Student>(students);
    students.clear();
    for(Student aStudent : copyOfStudents)
    {
      aStudent.removeJob(this);
    }
    JobManager placeholderJobManager = jobManager;
    this.jobManager = null;
    placeholderJobManager.removeJob(this);
  }


  public String toString()
  {
    return super.toString() + "["+
            "id" + ":" + getId()+ "," +
            "salary" + ":" + getSalary()+ "," +
            "requirements" + ":" + getRequirements()+ "]" + System.getProperties().getProperty("line.separator") +
            "  " + "requiredTime" + "=" + (getRequiredTime() != null ? !getRequiredTime().equals(this)  ? getRequiredTime().toString().replaceAll("  ","    ") : "this" : "null") + System.getProperties().getProperty("line.separator") +
            "  " + "jobManager = "+(getJobManager()!=null?Integer.toHexString(System.identityHashCode(getJobManager())):"null");
  }
}