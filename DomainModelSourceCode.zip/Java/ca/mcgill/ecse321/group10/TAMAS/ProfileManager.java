/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-89f4041 modeling language!*/

package ca.mcgill.ecse321.group10.TAMAS;
import java.util.*;

// line 82 "../../../../../../../../ump/tmp20095/model.ump"
// line 137 "../../../../../../../../ump/tmp20095/model.ump"
public class ProfileManager
{

  //------------------------
  // STATIC VARIABLES
  //------------------------

  private static ProfileManager theInstance = null;

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //ProfileManager Associations
  private List<Profile> profiles;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private ProfileManager()
  {
    profiles = new ArrayList<Profile>();
  }

  public static ProfileManager getInstance()
  {
    if(theInstance == null)
    {
      theInstance = new ProfileManager();
    }
    return theInstance;
  }

  //------------------------
  // INTERFACE
  //------------------------

  public Profile getProfile(int index)
  {
    Profile aProfile = profiles.get(index);
    return aProfile;
  }

  public List<Profile> getProfiles()
  {
    List<Profile> newProfiles = Collections.unmodifiableList(profiles);
    return newProfiles;
  }

  public int numberOfProfiles()
  {
    int number = profiles.size();
    return number;
  }

  public boolean hasProfiles()
  {
    boolean has = profiles.size() > 0;
    return has;
  }

  public int indexOfProfile(Profile aProfile)
  {
    int index = profiles.indexOf(aProfile);
    return index;
  }

  public static int minimumNumberOfProfiles()
  {
    return 0;
  }

  public Profile addProfile(String aId, String aUsername, String aPassword, String aFirstName, String aLastName)
  {
    return new Profile(aId, aUsername, aPassword, aFirstName, aLastName, this);
  }

  public boolean addProfile(Profile aProfile)
  {
    boolean wasAdded = false;
    if (profiles.contains(aProfile)) { return false; }
    ProfileManager existingProfileManager = aProfile.getProfileManager();
    boolean isNewProfileManager = existingProfileManager != null && !this.equals(existingProfileManager);
    if (isNewProfileManager)
    {
      aProfile.setProfileManager(this);
    }
    else
    {
      profiles.add(aProfile);
    }
    wasAdded = true;
    return wasAdded;
  }

  public boolean removeProfile(Profile aProfile)
  {
    boolean wasRemoved = false;
    //Unable to remove aProfile, as it must always have a profileManager
    if (!this.equals(aProfile.getProfileManager()))
    {
      profiles.remove(aProfile);
      wasRemoved = true;
    }
    return wasRemoved;
  }

  public boolean addProfileAt(Profile aProfile, int index)
  {  
    boolean wasAdded = false;
    if(addProfile(aProfile))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfProfiles()) { index = numberOfProfiles() - 1; }
      profiles.remove(aProfile);
      profiles.add(index, aProfile);
      wasAdded = true;
    }
    return wasAdded;
  }

  public boolean addOrMoveProfileAt(Profile aProfile, int index)
  {
    boolean wasAdded = false;
    if(profiles.contains(aProfile))
    {
      if(index < 0 ) { index = 0; }
      if(index > numberOfProfiles()) { index = numberOfProfiles() - 1; }
      profiles.remove(aProfile);
      profiles.add(index, aProfile);
      wasAdded = true;
    } 
    else 
    {
      wasAdded = addProfileAt(aProfile, index);
    }
    return wasAdded;
  }

  public void delete()
  {
    while (profiles.size() > 0)
    {
      Profile aProfile = profiles.get(profiles.size() - 1);
      aProfile.delete();
      profiles.remove(aProfile);
    }
    
  }

}